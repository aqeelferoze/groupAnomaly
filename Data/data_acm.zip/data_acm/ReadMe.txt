1. acm_complete.mat containes two elements:
author_adj is the coo-authorship network. Each cell denotes one year.
doc_bow is the bag of words vector of all the papers associated with each author.Each cell denotes one year.

2. acm_dictionary.txt is the binary vocabulary file.
It can be loaded using Python library
Gensim, with the function in corpora.Dictionary.load. The total number of terms is 8025.

3. acm_author.txt is the names of 4474 authors.

